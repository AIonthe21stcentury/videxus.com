"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Video,
  Wand2,
  Zap,
  Cloud,
  Code2,
  CreditCard,
  Clock,
  Settings,
  Star
} from "lucide-react";
import { supabase } from "@/lib/supabase";

export default function Home() {
  const [prompt, setPrompt] = useState("");
  const [duration, setDuration] = useState(15);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState("");

  const handleGenerate = async () => {
    try {
      setIsGenerating(true);
      setError("");

      const response = await fetch("/api/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          prompt,
          duration,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to generate video");
      }

      // Handle successful generation
      console.log("Video generation started:", data.videoId);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary">
      {/* Hero Section */}
      <section className="container mx-auto px-4 py-24 text-center">
        <div className="flex items-center justify-center mb-8">
          <Video className="h-12 w-12 text-primary mr-4" />
          <h1 className="text-4xl md:text-6xl font-bold">AI Video Creator</h1>
        </div>
        <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto mb-12">
          Create ultra-realistic videos from text or images using advanced AI technology.
          No technical skills required.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" className="text-lg" onClick={handleGenerate} disabled={isGenerating}>
            {isGenerating ? "Generating..." : "Try for Free"}
            <Wand2 className="ml-2 h-5 w-5" />
          </Button>
          <Button size="lg" variant="outline" className="text-lg">
            View Demo
            <Video className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Video Generation Section */}
      <section className="container mx-auto px-4 py-12">
        <Card className="max-w-2xl mx-auto p-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="prompt">Video Description</Label>
              <Input
                id="prompt"
                placeholder="Describe your video..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="duration">Duration (seconds)</Label>
              <Input
                id="duration"
                type="number"
                min={1}
                max={60}
                value={duration}
                onChange={(e) => setDuration(parseInt(e.target.value, 10))}
              />
            </div>
            {error && (
              <p className="text-sm text-destructive">{error}</p>
            )}
            <Button 
              className="w-full" 
              onClick={handleGenerate}
              disabled={isGenerating}
            >
              {isGenerating ? "Generating..." : "Generate Video"}
              <Wand2 className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </Card>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-24">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">
          Powerful Features for Video Creation
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <FeatureCard
            icon={<Zap className="h-8 w-8" />}
            title="AI-Powered Generation"
            description="Transform text into stunning videos using state-of-the-art AI models"
          />
          <FeatureCard
            icon={<Cloud className="h-8 w-8" />}
            title="Cloud Processing"
            description="No powerful hardware needed - all processing done in the cloud"
          />
          <FeatureCard
            icon={<Settings className="h-8 w-8" />}
            title="Customization Options"
            description="Adjust resolution, frame rate, and effects to match your vision"
          />
          <FeatureCard
            icon={<Clock className="h-8 w-8" />}
            title="Fast Generation"
            description="Get your videos quickly with optimized AI processing"
          />
          <FeatureCard
            icon={<Code2 className="h-8 w-8" />}
            title="API Access"
            description="Integrate video generation directly into your applications"
          />
          <FeatureCard
            icon={<Star className="h-8 w-8" />}
            title="Ultra-Realistic Quality"
            description="Enhanced realism with advanced AI upscaling and refinement"
          />
        </div>
      </section>

      {/* Pricing Section */}
      <section className="container mx-auto px-4 py-24">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">
          Simple, Transparent Pricing
        </h2>
        <Tabs defaultValue="monthly" className="max-w-5xl mx-auto">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-12">
            <TabsTrigger value="monthly">Monthly Billing</TabsTrigger>
            <TabsTrigger value="annual">Annual Billing</TabsTrigger>
          </TabsList>
          <TabsContent value="monthly">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <PricingCard
                title="Free Trial"
                price="$0"
                description="Perfect for testing"
                features={[
                  "2 free video generations",
                  "Up to 15-second videos",
                  "Basic customization",
                  "720p resolution"
                ]}
                buttonText="Start Free Trial"
                buttonVariant="outline"
              />
              <PricingCard
                title="Pro"
                price="$29.99"
                description="For content creators"
                features={[
                  "Unlimited video generations",
                  "Up to 60-second videos",
                  "Advanced customization",
                  "4K resolution",
                  "Priority processing"
                ]}
                buttonText="Get Started"
                buttonVariant="default"
                featured={true}
              />
              <PricingCard
                title="Enterprise"
                price="Custom"
                description="For businesses"
                features={[
                  "API access",
                  "Bulk generation",
                  "Custom integration",
                  "Dedicated support",
                  "Custom contracts"
                ]}
                buttonText="Contact Sales"
                buttonVariant="outline"
              />
            </div>
          </TabsContent>
          <TabsContent value="annual">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <PricingCard
                title="Free Trial"
                price="$0"
                description="Perfect for testing"
                features={[
                  "2 free video generations",
                  "Up to 15-second videos",
                  "Basic customization",
                  "720p resolution"
                ]}
                buttonText="Start Free Trial"
                buttonVariant="outline"
              />
              <PricingCard
                title="Pro"
                price="$24.99"
                description="For content creators"
                features={[
                  "Unlimited video generations",
                  "Up to 60-second videos",
                  "Advanced customization",
                  "4K resolution",
                  "Priority processing"
                ]}
                buttonText="Get Started"
                buttonVariant="default"
                featured={true}
              />
              <PricingCard
                title="Enterprise"
                price="Custom"
                description="For businesses"
                features={[
                  "API access",
                  "Bulk generation",
                  "Custom integration",
                  "Dedicated support",
                  "Custom contracts"
                ]}
                buttonText="Contact Sales"
                buttonVariant="outline"
              />
            </div>
          </TabsContent>
        </Tabs>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-24">
        <div className="bg-card rounded-3xl p-12 text-center max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Create Amazing Videos?
          </h2>
          <p className="text-xl text-muted-foreground mb-8">
            Start with 2 free videos today. No credit card required.
          </p>
          <Button size="lg" className="text-lg">
            Get Started Now
            <CreditCard className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>
    </div>
  );
}

function FeatureCard({ icon, title, description }: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <Card className="p-6 hover:shadow-lg transition-shadow">
      <div className="mb-4 text-primary">{icon}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </Card>
  );
}

function PricingCard({ 
  title, 
  price, 
  description, 
  features, 
  buttonText, 
  buttonVariant = "default",
  featured = false 
}: {
  title: string;
  price: string;
  description: string;
  features: string[];
  buttonText: string;
  buttonVariant?: "default" | "outline";
  featured?: boolean;
}) {
  return (
    <Card className={`p-8 ${featured ? 'border-primary shadow-lg' : ''}`}>
      <h3 className="text-2xl font-bold mb-2">{title}</h3>
      <div className="text-4xl font-bold mb-2">
        {price}
        {price !== "Custom" && <span className="text-lg text-muted-foreground">/mo</span>}
      </div>
      <p className="text-muted-foreground mb-6">{description}</p>
      <ul className="space-y-4 mb-8">
        {features.map((feature, index) => (
          <li key={index} className="flex items-center">
            <Star className="h-5 w-5 text-primary mr-2" />
            {feature}
          </li>
        ))}
      </ul>
      <Button className="w-full" variant={buttonVariant}>
        {buttonText}
      </Button>
    </Card>
  );
}