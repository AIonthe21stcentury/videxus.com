import { createClient } from '@supabase/supabase-js';
import { NextResponse } from 'next/server';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export async function POST(req: Request) {
  try {
    const { prompt, duration } = await req.json();
    
    // Get user from session
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Check user's subscription status
    const { data: user } = await supabase
      .from('users')
      .select('subscription_tier')
      .eq('id', session.user.id)
      .single();

    // Validate duration based on subscription
    const maxDuration = user?.subscription_tier === 'pro' ? 60 : 15;
    if (duration > maxDuration) {
      return NextResponse.json(
        { error: `Maximum video duration for your plan is ${maxDuration} seconds` },
        { status: 400 }
      );
    }

    // Mock video generation (in real implementation, this would call the AI service)
    const videoId = crypto.randomUUID();
    
    // Store video metadata
    await supabase.from('videos').insert({
      id: videoId,
      user_id: session.user.id,
      prompt,
      duration,
      status: 'processing'
    });

    return NextResponse.json({ 
      videoId,
      message: 'Video generation started'
    });
  } catch (error) {
    console.error('Error generating video:', error);
    return NextResponse.json(
      { error: 'Failed to generate video' },
      { status: 500 }
    );
  }
}